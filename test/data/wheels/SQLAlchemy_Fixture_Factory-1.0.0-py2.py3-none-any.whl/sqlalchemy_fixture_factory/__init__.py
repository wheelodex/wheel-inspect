# -*- coding: utf-8 -*-

"""
Copyright (c) 2005, Michael Pickelbauer
License: MIT (see LICENSE for details)
"""

from __future__ import absolute_import, print_function, unicode_literals, division

__version__ = '1.0.0'


